Write-Output "Enabling SMB 1.0 protocol..."
Enable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -WarningAction SilentlyContinue | Out-Null 
